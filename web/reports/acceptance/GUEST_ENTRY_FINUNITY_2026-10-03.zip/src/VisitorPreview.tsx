import { Link, useLocation } from "react-router-dom";
import type { Locale } from "./types";
import "./VisitorPreview.css";

export function VisitorPreview({ locale, setLocale, notice, onRetry }: {
  locale: Locale; setLocale: (value: Locale) => void; notice?: string; onRetry?: () => void;
}) {
  const en = locale === "en-US";
  const path = useLocation().pathname;
  const tab = path.includes("holdings") ? "holdings" : path.includes("flows") ? "flows" : "overview";
  const copy = (zh: string, english: string) => en ? english : zh;
  return <main className="visitor-page">
    <header className="visitor-nav"><a href={en ? "/en/" : "/"}>衡仓 <span>FinUnity</span></a><div>
      <button onClick={() => setLocale(en ? "zh-CN" : "en-US")}>{en ? "中文" : "English"}</button>
      <Link to="/login">{copy("登录", "Sign in")}</Link></div></header>
    <section className="visitor-intro"><p className="eyebrow">FINUNITY</p><h1>{copy("先看一份清楚的账本", "Explore a clear ledger")}</h1>
      <p>{copy("无需登录即可查看示例。保存自己的账户、导入持仓或同步资料时，再登录账号。", "Browse the example without an account. Sign in when you save your own accounts, import holdings or sync your data.")}</p>
      <p className="visitor-label">{copy("只读示例 · 数字与账户全部虚构 · 示例汇率不是实时行情", "Read-only example · All accounts and amounts are fictional · Rates are not live quotes")}</p>
      {notice && <p role="status">{notice} {onRetry && <button onClick={onRetry}>{copy("重试账号连接", "Retry account connection")}</button>}</p>}
    </section>
    <nav className="visitor-tabs" aria-label={copy("示例账本", "Example ledger")}>
      {[["overview", "/app", copy("资产概览", "Overview")], ["holdings", "/app/holdings", copy("持仓", "Holdings")], ["flows", "/app/flows", copy("流水", "Transactions")]].map(([key, href, title]) => <Link key={key} to={href} aria-current={tab === key ? "page" : undefined}>{title}</Link>)}
    </nav>
    <section className="visitor-content">
      {tab === "overview" ? <><h2>{copy("资产概览", "Asset overview")}</h2><div className="visitor-metrics">
        <article><span>{copy("人民币账户", "CNY account")}</span><strong>CNY 15,000</strong><small>{copy("现金 10,000 + 持仓 5,000", "Cash 10,000 + holdings 5,000")}</small></article>
        <article><span>{copy("美元账户", "USD account")}</span><strong>USD 1,500</strong><small>{copy("现金 1,000 + 持仓 500", "Cash 1,000 + holdings 500")}</small></article>
        <article><span>{copy("示例折合总额", "Illustrative total")}</span><strong>CNY 25,500</strong><small>{copy("仅按虚构 USD→CNY 汇率 7 计算", "At a fictional USD→CNY rate of 7")}</small></article>
      </div><img className="visitor-example" src={en ? "/ledger-example.en.svg" : "/ledger-example.zh.svg"} width="820" height="480" alt={copy("虚构账本的资产与三桶配置示意", "Fictional ledger and three-bucket illustration")} /></>
      : <><h2>{copy(tab === "holdings" ? "示例持仓" : "示例流水", tab === "holdings" ? "Example holdings" : "Example transactions")}</h2><div className="visitor-table"><table><thead><tr>
        <th>{copy("账户", "Account")}</th><th>{copy("记录", "Record")}</th><th>{copy("币种", "Currency")}</th><th>{copy("金额", "Amount")}</th>
      </tr></thead><tbody><tr><td>{copy("人民币示例账户", "Example CNY account")}</td><td>{copy(tab === "holdings" ? "虚构持仓 A" : "期初现金", tab === "holdings" ? "Fictional holding A" : "Opening cash")}</td><td>CNY</td><td>{tab === "holdings" ? "5,000" : "10,000"}</td></tr>
        <tr><td>{copy("美元示例账户", "Example USD account")}</td><td>{copy(tab === "holdings" ? "虚构持仓 B" : "期初现金", tab === "holdings" ? "Fictional holding B" : "Opening cash")}</td><td>USD</td><td>{tab === "holdings" ? "500" : "1,000"}</td></tr></tbody></table></div></>}
      <div className="visitor-actions"><Link className="primary-button" to="/login">{copy(tab === "holdings" ? "导入我的持仓" : "保存我的账本", tab === "holdings" ? "Import my holdings" : "Save my ledger")}</Link><Link to="/register">{copy("创建账号", "Create account")}</Link></div>
      <p>{copy("行情仅供参考，识别结果需要核对。衡仓不执行交易。", "Prices are reference data and recognition needs review. FinUnity does not execute trades.")}</p>
    </section>
    <footer className="visitor-footer"><a href={en ? "/en/guides/multi-currency/" : "/guides/multi-currency/"}>{copy("币种汇总指南", "Currency guide")}</a><a href={en ? "/en/guides/holding-import/" : "/guides/holding-import/"}>{copy("持仓导入指南", "Import guide")}</a><a href={en ? "/privacy-en.html" : "/privacy"}>{copy("隐私政策", "Privacy policy")}</a></footer>
  </main>;
}
