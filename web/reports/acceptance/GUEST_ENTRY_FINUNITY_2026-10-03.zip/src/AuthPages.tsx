import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Link, useNavigate } from "react-router-dom";
import { api, createClientRequestId, type AuthResult } from "./api";
import type { Locale, User } from "./types";
import { policyHref, translate, type MessageKey } from "./i18n";
import { FileImage, RefreshCw, ShieldCheck, Sparkles } from "lucide-react";

const english: Record<string, string> = {
  "请保存恢复码": "Save your recovery code",
  "恢复码只在此处显示一次，用于忘记密码时找回账号。请保存在可信位置，勿分享给他人。": "This code is shown once. Store it securely to recover your account; do not share it.",
  "我已保存恢复码": "I have saved the recovery code",
  "进入应用": "Continue",
  "请求失败": "Request failed",
  "验证码已发送": "Verification code sent",
  "为旧账号设置用户名": "Set a username for your existing account",
  "创建账号": "Create account",
  "使用恢复码找回密码": "Recover password with your code",
  "登录 FinUnity": "Sign in to FinUnity",
  "账户、持仓与流水使用同一份账本。行情为参考数据，请核对识别结果后再导入。": "Accounts, holdings and transactions share one ledger. Prices are reference data; review recognized rows before importing.",
  "原账号的数据将保留。设置用户名并保存恢复码后，可继续使用。": "Your data is preserved. Set a username and save your recovery code to continue.",
  "旧账号邮箱": "Existing account email",
  "用户名（旧账号可输入邮箱登录）": "Username (existing accounts may use email)",
  "用户名": "Username",
  "3～32 位字母、数字、下划线或短横线，不区分大小写。": "3–32 ASCII letters, digits, underscores or hyphens; case insensitive.",
  "显示名称（可选）": "Display name (optional)",
  "恢复码": "Recovery code",
  "邮箱验证码": "Email code",
  "发送验证码": "Send code",
  "新密码": "New password",
  "密码": "Password",
  "再次输入密码": "Confirm password",
  "我已阅读并同意": "I have read and agree to the",
  "隐私政策": "Privacy policy",
  "和": "and",
  "用户协议": "Terms of use",
  "处理中…": "Working…",
  "返回登录": "Back to sign in",
  "忘记密码？使用恢复码": "Forgot password? Use recovery code",
  "切换密码 / 邮箱验证码登录": "Switch password / email-code sign in",
  "已有账号，登录": "Already registered? Sign in",
  "注册账号": "Register",
  "已更新，其他会话已失效。": "Updated; older sessions are invalid.",
  "账号安全与数据": "Account security and data",
  "当前密码": "Current password",
  "再次输入新密码": "Confirm new password",
  "修改密码": "Change password",
  "重新生成恢复码": "Regenerate recovery code",
  "导出我的账户、持仓、流水 JSON": "Export my accounts, holdings and transactions as JSON",
  "确认永久注销账号并删除所有云端业务数据（含归档）": "Confirm permanent account deletion, including archived cloud data",
  "注销账号": "Delete account"
};
const localize = (locale: Locale, value: string) => locale === "zh-CN" ? value : english[value] || value;

type Props = { locale: Locale; setLocale: (locale: Locale) => void; onSignedIn: (u: User) => void };

export function RecoveryNotice({ result, onSaved, locale = "zh-CN" }: { result: AuthResult; onSaved: () => void; locale?: Locale }) {
  const copy = (value: string) => localize(locale, value);
  const [saved, setSaved] = useState(false);
  return <section className="register-card" aria-live="polite">
    <h2>{copy("请保存恢复码")}</h2>
    <p>{copy("恢复码只在此处显示一次，用于忘记密码时找回账号。请保存在可信位置，勿分享给他人。")}</p>
    <pre style={{ whiteSpace: "pre-wrap", overflowWrap: "anywhere" }}>{result.recovery_code}</pre>
    <label className="consent-row"><input type="checkbox" checked={saved} onChange={e => setSaved(e.target.checked)} /> {copy("我已保存恢复码")}</label>
    <button className="primary-button" disabled={!saved} onClick={onSaved}>{copy("进入应用")}</button>
  </section>;
}

function CredentialsPage({ locale, setLocale, onSignedIn, register = false, migrate = false }: Props & {
  register?: boolean; migrate?: boolean;
}) {
  const copy = (value: string) => localize(locale, value);
  const navigate = useNavigate();
  const landing = !register && !migrate;
  const t = (key: MessageKey) => translate(locale, key);
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [recoveryCode, setRecoveryCode] = useState("");
  const [reset, setReset] = useState(false);
  const [emailCodeMode, setEmailCodeMode] = useState(false);
  const [emailCode, setEmailCode] = useState("");
  const [consent, setConsent] = useState(false);
  const [pending, setPending] = useState<AuthResult | null>(null);
  const [message, setMessage] = useState("");
  const config = useQuery({ queryKey: ["auth-config"], queryFn: api.authConfig, retry: 1 });
  const finish = (result: AuthResult) => {
    onSignedIn(api.completeAuth(result));
    navigate("/app");
  };
  const action = useMutation({
    mutationFn: async () => {
      if (migrate) return api.setUsername(username, password);
      if (register) return api.registerUsername(username, password, confirmation, name, consent);
      if (reset) return api.recoverPassword(username, recoveryCode, password, confirmation);
      const user = emailCodeMode
        ? await api.login(username, emailCode, createClientRequestId())
        : await api.loginWithPassword(username, password, createClientRequestId());
      onSignedIn(user);
      navigate("/app");
      return null;
    },
    onSuccess: result => { if (result) setPending(result); },
    onError: error => setMessage(error instanceof Error ? error.message : copy("请求失败")),
  });
  const sendCode = useMutation({
    mutationFn: () => api.sendCode(username, "login", locale),
    onSuccess: data => setMessage(
      data.dev_code
        ? locale === "zh-CN"
          ? `本地验证码：${data.dev_code}`
          : `Local verification code: ${data.dev_code}`
        : copy("验证码已发送"),
    ),
    onError: error => setMessage(error.message),
  });
  const title = migrate ? copy("为旧账号设置用户名") : register ? copy("创建账号") : reset ? copy("使用恢复码找回密码") : copy("登录 FinUnity");
  return <main className={landing ? "public-page" : "register-page"}>
    <header className="public-nav"><a className="public-brand" href="/"><span className="brand-mark">F</span><span>FinUnity<small>{t("brandTagline")}</small></span></a>
      <button
        className="language-toggle"
        type="button"
        aria-label={t(locale === "zh-CN" ? "switchToEnglish" : "switchToChinese")}
        onClick={() => setLocale(locale === "zh-CN" ? "en-US" : "zh-CN")}
      >
        {locale === "zh-CN" ? "English" : "中文"}
      </button>
    </header>
    <section className={landing ? "landing-grid" : "register-wrap"}>
      {landing ? <div className="landing-copy">
        <p className="eyebrow"><Sparkles />{t("heroEyebrow")}</p>
        <h1>{t("heroTitle").split("\n").map(line => <span key={line}>{line}</span>)}</h1>
        <p className="hero-body">{t("heroBody")}</p>
        <div className="trust-list"><span><ShieldCheck />{t("trustOne")}</span><span><RefreshCw />{t("trustTwo")}</span><span><FileImage />{t("trustThree")}</span></div>
        <p>{copy("账户、持仓与流水使用同一份账本。行情为参考数据，请核对识别结果后再导入。")}</p>
      </div> : <div className="register-intro"><p className="eyebrow">FINUNITY</p><h1>{title}</h1>
        <p>{copy("账户、持仓与流水使用同一份账本。行情为参考数据，请核对识别结果后再导入。")}</p>
        {migrate && <p>{copy("原账号的数据将保留。设置用户名并保存恢复码后，可继续使用。")}</p>}
      </div>}
      {pending ? <RecoveryNotice locale={locale} result={pending} onSaved={() => finish(pending)} /> :
      <form className="register-card" onSubmit={e => { e.preventDefault(); setMessage(""); action.mutate(); }}>
        {landing && <h2>{title}</h2>}
        {message && <p role="alert">{message}</p>}
        <label className="field">{emailCodeMode ? copy("旧账号邮箱") : copy(register || reset || migrate ? "用户名" : "用户名（旧账号可输入邮箱登录）")}
          <input value={username} onChange={e => setUsername(e.target.value)} required
            autoComplete="username" minLength={3} maxLength={register || reset || migrate ? 32 : 254}
            pattern={register || reset || migrate ? "[A-Za-z0-9_-]{3,32}" : undefined} />
        </label>
        {(register || migrate) && <small>{copy("3～32 位字母、数字、下划线或短横线，不区分大小写。")}</small>}
        {register && <label className="field">{copy("显示名称（可选）")}<input value={name} maxLength={100} onChange={e => setName(e.target.value)} /></label>}
        {reset && <label className="field">{copy("恢复码")}<input value={recoveryCode} onChange={e => setRecoveryCode(e.target.value)} required autoComplete="off" /></label>}
        {emailCodeMode ? <><label className="field">{copy("邮箱验证码")}<input value={emailCode} onChange={e => setEmailCode(e.target.value)} pattern="[0-9]{6}" required /></label>
          <button type="button" className="secondary-button" disabled={sendCode.isPending} onClick={() => sendCode.mutate()}>{copy("发送验证码")}</button></> :
        <label className="field">{reset ? copy("新密码") : copy("密码")}<input type="password" value={password} onChange={e => setPassword(e.target.value)}
          autoComplete={register || reset ? "new-password" : "current-password"} minLength={8} maxLength={128} required /></label>}
        {(register || reset) && <label className="field">{copy("再次输入密码")}<input type="password" value={confirmation} onChange={e => setConfirmation(e.target.value)} autoComplete="new-password" minLength={8} maxLength={128} required /></label>}
        {register && <label className="consent-row"><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} required />{copy("我已阅读并同意")} <a href={policyHref(locale, "privacy")} target="_blank" rel="noreferrer">{copy("隐私政策")}</a> {copy("和")} <a href={policyHref(locale, "terms")} target="_blank" rel="noreferrer">{copy("用户协议")}</a></label>}
        <button className="primary-button" disabled={action.isPending}>{action.isPending ? copy("处理中…") : title}</button>
        {!register && !migrate && <button type="button" className="text-link" onClick={() => { setReset(!reset); setEmailCodeMode(false); setMessage(""); }}>{reset ? copy("返回登录") : copy("忘记密码？使用恢复码")}</button>}
        {!register && !reset && !migrate && config.data?.email_auth_enabled && <button type="button" className="text-link" onClick={() => setEmailCodeMode(!emailCodeMode)}>{copy("切换密码 / 邮箱验证码登录")}</button>}
        {!migrate && <Link className="text-link" to={register ? "/login" : "/register"}>{register ? copy("已有账号，登录") : copy("注册账号")}</Link>}
        <a className="text-link" href={policyHref(locale, "privacy")}>{copy("隐私政策")}</a>
      </form>}
    </section>
  </main>;
}

export const PublicHome = (props: Props) => <CredentialsPage {...props} />;
export const RegisterPage = (props: Props) => <CredentialsPage {...props} register />;
export const UsernameMigration = (props: Props) => <CredentialsPage {...props} migrate />;

export function AccountSecurity({ onLogout, locale }: { onLogout: () => void; locale: Locale }) {
  const copy = (value: string) => localize(locale, value);
  const [password, setPassword] = useState("");
  const [next, setNext] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [deleteConfirmed, setDeleteConfirmed] = useState(false);
  const [recovery, setRecovery] = useState<AuthResult | null>(null);
  const [message, setMessage] = useState("");
  const action = useMutation({
    mutationFn: async (kind: "change" | "regenerate" | "delete" | "export") => {
      if (kind === "export") {
        const data = await api.exportData();
        const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
        const a = document.createElement("a"); a.href = url; a.download = "finunity-export.json"; a.click();
        setTimeout(() => URL.revokeObjectURL(url), 1000); return;
      }
      if (kind === "delete") { await api.deleteAccount(password); onLogout(); return; }
      if (kind === "regenerate") setRecovery(await api.regenerateRecovery(password));
      else await api.changePassword(password, next, confirmation);
      setPassword(""); setNext(""); setConfirmation("");
      setMessage(copy("已更新，其他会话已失效。"));
    },
    onError: error => setMessage(error.message),
  });
  if (recovery) return <RecoveryNotice locale={locale} result={recovery} onSaved={() => setRecovery(null)} />;
  return <section className="account-security"><h3>{copy("账号安全与数据")}</h3>
    {message && <p role="status">{message}</p>}
    <label className="field">{copy("当前密码")}<input type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" /></label>
    <label className="field">{copy("新密码")}<input type="password" value={next} onChange={e => setNext(e.target.value)} autoComplete="new-password" /></label>
    <label className="field">{copy("再次输入新密码")}<input type="password" value={confirmation} onChange={e => setConfirmation(e.target.value)} autoComplete="new-password" /></label>
    <button className="secondary-button" disabled={action.isPending || !password || !next || !confirmation} onClick={() => action.mutate("change")}>{copy("修改密码")}</button>
    <button className="secondary-button" disabled={action.isPending || !password} onClick={() => action.mutate("regenerate")}>{copy("重新生成恢复码")}</button>
    <button className="secondary-button" disabled={action.isPending} onClick={() => action.mutate("export")}>{copy("导出我的账户、持仓、流水 JSON")}</button>
    <label className="consent-row"><input type="checkbox" checked={deleteConfirmed} onChange={e => setDeleteConfirmed(e.target.checked)} />{copy("确认永久注销账号并删除所有云端业务数据（含归档）")}</label>
    <button className="danger-button" disabled={action.isPending || !password || !deleteConfirmed} onClick={() => action.mutate("delete")}>{copy("注销账号")}</button>
  </section>;
}
